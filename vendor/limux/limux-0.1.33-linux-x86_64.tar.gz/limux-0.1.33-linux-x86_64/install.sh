#!/usr/bin/env bash
set -euo pipefail

PREFIX="/usr/local"
GHOSTTY_LIBRARY_NAME="libghostty-internal.so"
LEGACY_GHOSTTY_LIBRARY_NAME="libghostty.so"
UNINSTALL=false

for arg in "$@"; do
    case "$arg" in
        --prefix=*) PREFIX="${arg#*=}" ;;
        --uninstall) UNINSTALL=true ;;
        -h|--help)
            echo "Usage: install.sh [--prefix=/usr/local] [--uninstall]"
            exit 0
            ;;
    esac
done

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

need_root() {
    if [ "$(id -u)" -ne 0 ]; then
        echo "This operation requires root. Re-running with sudo..."
        exec sudo "$0" "$@"
    fi
}

install_desktop_file() {
    local src="$1"
    local dest="$2"
    local exec_path="$3"

    sed \
        -e "s|^Exec=.*|Exec=${exec_path}|" \
        -e "s|^TryExec=.*|TryExec=${exec_path}|" \
        "$src" > "$dest"
    chmod 644 "$dest"
}

legacy_limux_paths() {
    local sudo_home=""

    if [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != "root" ]; then
        sudo_home="$(getent passwd "$SUDO_USER" 2>/dev/null | cut -d: -f6 || true)"
    fi

    printf '%s\n' \
        "$PREFIX/libexec/limux/limux" \
        /usr/local/libexec/limux/limux \
        /usr/libexec/limux/limux \
        /usr/local/bin/limux \
        /usr/bin/limux

    if [ -n "$sudo_home" ]; then
        printf '%s\n' \
            "$sudo_home/.local/libexec/limux/limux" \
            "$sudo_home/.local/bin/limux"
    fi
}

is_legacy_limux_host() {
    local path="$1"
    local help

    [ -x "$path" ] || return 1
    help="$("$path" --help 2>&1 || true)"
    grep -q "limux CLI" <<< "$help" && return 1
    grep -q "GApplication" <<< "$help" && return 0
    "$path" --json identify >/tmp/limux-installer-probe.log 2>&1 && return 1
    grep -q "Unknown option --json" /tmp/limux-installer-probe.log
}

clean_legacy_limux_entrypoints() {
    local path

    while IFS= read -r path; do
        [ -n "$path" ] || continue
        [ "$path" = "$PREFIX/bin/limux" ] && continue
        if [ "${path%/bin/limux}" != "$path" ]; then
            if is_legacy_limux_host "$path"; then
                rm -f "$path"
                echo "Removed legacy Limux host entrypoint: $path"
            fi
        elif [ -e "$path" ]; then
            rm -f "$path"
            echo "Removed legacy Limux host entrypoint: $path"
        fi
    done <<EOF_PATHS
$(legacy_limux_paths)
EOF_PATHS
}

warn_if_limux_is_shadowed() {
    local expected="$PREFIX/bin/limux"
    local first
    local help

    first="$(PATH="$PREFIX/bin:$PATH" command -v limux 2>/dev/null || true)"
    if [ "$first" != "$expected" ]; then
        echo "WARNING: the first limux on PATH is '$first', expected '$expected'."
        echo "         Agent/CLI commands require the Limux CLI entrypoint."
    fi

    if ! help="$("$expected" --help 2>&1)" || ! grep -q "limux CLI" <<< "$help"; then
        echo "ERROR: installed limux entrypoint is not the CLI: $expected" >&2
        exit 1
    fi
}

remove_tree() {
    local path="$1"

    if [ ! -e "$path" ]; then
        return 0
    fi

    find "$path" -depth -mindepth 1 ! -type d -exec rm -f {} +
    find "$path" -depth -mindepth 1 -type d -exec rmdir {} + 2>/dev/null || true
    rmdir "$path" 2>/dev/null || true
}

if $UNINSTALL; then
    need_root "$@"
    echo "Uninstalling Limux..."
    rm -f "$PREFIX/bin/limux"
    remove_tree "$PREFIX/libexec/limux"
    remove_tree "$PREFIX/lib/limux"
    remove_tree "$PREFIX/share/limux"
    rm -f /etc/ld.so.conf.d/limux.conf
    ldconfig 2>/dev/null || true
    rm -f "$PREFIX/share/applications/limux.desktop"
    rm -f "$PREFIX/share/applications/dev.limux.linux.desktop"
    rm -f "$PREFIX/share/metainfo/dev.limux.linux.metainfo.xml"
    for size in 16 32 128 256 512; do
        rm -f "$PREFIX/share/icons/hicolor/${size}x${size}/apps/limux.png"
    done
    rm -f "$PREFIX/share/icons/hicolor/scalable/actions/limux-globe-symbolic.svg"
    rm -f "$PREFIX/share/icons/hicolor/scalable/actions/limux-split-horizontal-symbolic.svg"
    rm -f "$PREFIX/share/icons/hicolor/scalable/actions/limux-split-vertical-symbolic.svg"
    gtk-update-icon-cache -f -t "$PREFIX/share/icons/hicolor" 2>/dev/null || true
    update-desktop-database "$PREFIX/share/applications" 2>/dev/null || true
    appstreamcli refresh-cache --force 2>/dev/null || true
    echo "Limux uninstalled."
    exit 0
fi

need_root "$@"
echo "Installing Limux to ${PREFIX}..."

install -Dm755 "$SCRIPT_DIR/limux" "$PREFIX/bin/limux"
clean_legacy_limux_entrypoints
install -Dm755 "$SCRIPT_DIR/libexec/limux/limux-host" "$PREFIX/libexec/limux/limux-host"
rm -f "$PREFIX/lib/limux/$LEGACY_GHOSTTY_LIBRARY_NAME"
install -Dm644 "$SCRIPT_DIR/lib/$GHOSTTY_LIBRARY_NAME" "$PREFIX/lib/limux/$GHOSTTY_LIBRARY_NAME"
if [ -d "$SCRIPT_DIR/share/limux" ]; then
    cp -r "$SCRIPT_DIR/share/limux" "$PREFIX/share/"
fi
echo "$PREFIX/lib/limux" > /etc/ld.so.conf.d/limux.conf
ldconfig 2>/dev/null || true
rm -f "$PREFIX/share/applications/limux.desktop"
mkdir -p "$PREFIX/share/applications"
install_desktop_file "$SCRIPT_DIR/share/applications/dev.limux.linux.desktop" "$PREFIX/share/applications/dev.limux.linux.desktop" "$PREFIX/bin/limux"
install -Dm644 "$SCRIPT_DIR/share/metainfo/dev.limux.linux.metainfo.xml" "$PREFIX/share/metainfo/dev.limux.linux.metainfo.xml"
if [ -d "$SCRIPT_DIR/share/icons" ]; then
    cp -r "$SCRIPT_DIR/share/icons/hicolor" "$PREFIX/share/icons/"
fi
gtk-update-icon-cache -f -t "$PREFIX/share/icons/hicolor" 2>/dev/null || true
update-desktop-database "$PREFIX/share/applications" 2>/dev/null || true
appstreamcli refresh-cache --force 2>/dev/null || true
warn_if_limux_is_shadowed

echo ""
echo "Limux installed successfully!"
echo "  CLI:     $PREFIX/bin/limux"
echo "  Host:    $PREFIX/libexec/limux/limux-host"
echo "  Library: $PREFIX/lib/limux/$GHOSTTY_LIBRARY_NAME"
echo "  App:     limux"
echo ""
echo "System dependencies (install if missing):"
echo "  sudo apt install libgtk-4-1 libadwaita-1-0 libwebkitgtk-6.0-4"
